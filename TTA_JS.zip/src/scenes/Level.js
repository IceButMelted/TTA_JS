
// You can write more code here

/* START OF COMPILED CODE */

import Food_Prefab from "../Food_Prefab.js";
import Bunny_Prefab from "./Bunny_Prefab.js";
/* START-USER-IMPORTS */
/* END-USER-IMPORTS */

export default class Level extends Phaser.Scene {

	constructor() {
		super("Level");

		/* START-USER-CTR-CODE */
		// Write your code here.
		/* END-USER-CTR-CODE */
	}

	/** @returns {void} */
	editorCreate() {

		// upKey
		const upKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.UP);

		// downKey
		const downKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.DOWN);

		// leftKey
		const leftKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.LEFT);

		// rightKey
		const rightKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.RIGHT);

		// dino001
		const dino001 = this.physics.add.image(605, 292, "dino");
		dino001.scaleX = 0.5;
		dino001.scaleY = 0.5;
		dino001.body.collideWorldBounds = true;
		dino001.body.setSize(208, 240, false);

		// aaaaa
		const aaaaa = new Food_Prefab(this, 87, 361);
		this.add.existing(aaaaa);

		// food_Prefab
		const food_Prefab = new Food_Prefab(this, 141, 137);
		this.add.existing(food_Prefab);

		// food_Prefab_1
		const food_Prefab_1 = new Food_Prefab(this, 238, 307);
		this.add.existing(food_Prefab_1);

		// dino
		const dino = this.physics.add.image(403, 288, "dino");
		dino.setInteractive(new Phaser.Geom.Rectangle(0, 0, 250, 250), Phaser.Geom.Rectangle.Contains);
		dino.scaleX = 0.5;
		dino.scaleY = 0.5;
		dino.body.collideWorldBounds = true;
		dino.body.setSize(250, 250, false);

		// ui
		const ui = this.add.layer();
		ui.blendMode = Phaser.BlendModes.SKIP_CHECK;

		// welcome
		const welcome = this.add.text(403, 478, "", {});
		welcome.setOrigin(0.5, 0.5);
		welcome.text = "Phaser 3 + Phaser Editor v4";
		welcome.setStyle({ "fontFamily": "Arial", "fontSize": "30px" });
		ui.add(welcome);

		// scoreText_1
		const scoreText_1 = this.add.text(10, 10, "", {});
		scoreText_1.text = "Score Text : ";
		scoreText_1.setStyle({ "fontSize": "24px" });
		ui.add(scoreText_1);

		// bunnyAllFramepng_x50
		const bunnyAllFramepng_x50 = new Bunny_Prefab(this, 75, 486);
		this.add.existing(bunnyAllFramepng_x50);

		// lists
		const food = [aaaaa, food_Prefab, food_Prefab_1];

		// DinoNFirut
		this.physics.add.overlap(dino, food, this.eatfurit, undefined, this);

		this.dino = dino;
		this.welcome = welcome;
		this.scoreText_1 = scoreText_1;
		this.upKey = upKey;
		this.downKey = downKey;
		this.leftKey = leftKey;
		this.rightKey = rightKey;
		this.food = food;

		this.events.emit("scene-awake");
	}

	/** @type {Phaser.Physics.Arcade.Image} */
	dino;
	/** @type {Phaser.GameObjects.Text} */
	welcome;
	/** @type {Phaser.GameObjects.Text} */
	scoreText_1;
	/** @type {Phaser.Input.Keyboard.Key} */
	upKey;
	/** @type {Phaser.Input.Keyboard.Key} */
	downKey;
	/** @type {Phaser.Input.Keyboard.Key} */
	leftKey;
	/** @type {Phaser.Input.Keyboard.Key} */
	rightKey;
	/** @type {Food_Prefab[]} */
	food;

	/* START-USER-CODE */

	// Write more your code here
	playerVelocity = 200;
	socre = 0;

	create() {

		this.editorCreate();

		this.dino.on("pointerdown", () => {

			this.welcome.text = "Hello, World!";
		});
	}

	update(){
		if (this.upKey.isDown){
			//this.dino.y -= 4;
			this.dino.setVelocityY(-this.playerVelocity);
		}
		else if (this.downKey.isDown){
			//this.dino.y += 4;
			this.dino.setVelocityY(this.playerVelocity);
		}
		else{
			this.dino.setVelocityY(0);
		}

		if (this.rightKey.isDown){
			//this.dino.x += 4;
			this.dino.setVelocityX(this.playerVelocity);
		}
		else if (this.leftKey.isDown){
			this.dino.setVelocityX(-this.playerVelocity);
		}
		else{
			this.dino.setVelocityX(0);
		}

	}

	eatfurit(dino, food){
		console.log("hit!!");
		food.disableBody();
		food.destroy();
		this.socre += 1;
		this.scoreText_1.setText("Score : " + this.socre);
	}

	/* END-USER-CODE */
}

/* END OF COMPILED CODE */

// You can write more code here
