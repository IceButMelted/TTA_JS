## v2.0.6 - Oct 11, 2024

* Updates to Phaser 3.86.

## v2.0.5 - Sep 28, 2024

* Adds `importModuleSpecifierEnding` VS Code settings.

## v2.0.4 - Sep 24, 2024

* Gets the new script node libraries.
* Removes the loading bar script nodes.

## v2.0.3 - Sep 19, 2024

* Change Phaser CDN.

## v2.0.2 - Sep 18, 2024

* Updates to Phaser 3.85.2.

## v2.0.1 - Sep 6, 2024

* Updates to Phaser 3.85.1.

## v2.0.0 - Apr 9, 2024

Migrate to Phaser Editor v4.